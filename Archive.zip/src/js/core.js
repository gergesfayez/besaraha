// @codekit-prepend "../../node_modules/lazysizes/lazysizes.js"


// @codekit-prepend "../../node_modules/pushbar.js/src/pushbar.js"


// init  pushbar 
new Pushbar({
    blur: true,
    overlay: true,
});



window.onscroll = function () {
    stickyEl();
};

var navbar = document.getElementById("navbar");
var sponserLeft = document.getElementById("stick-l");
var sponserRight = document.getElementById("stick-r");
var sticky = navbar.offsetTop;


function stickyEl() {
    if (window.pageYOffset >= sticky) {
        navbar.classList.add("sticky");
        sponserLeft.classList.add("stickyL"); 
        sponserRight.classList.add("stickyR");
    } else {
        navbar.classList.remove("sticky");
        sponserLeft.classList.remove("stickyL");
        sponserRight.classList.remove("stickyR");
    }


}